/* Because this is a "peripheral" function it will be defined in a separate file to reduce the amount of code in main.c */
void setupSWOForPrint(void);
